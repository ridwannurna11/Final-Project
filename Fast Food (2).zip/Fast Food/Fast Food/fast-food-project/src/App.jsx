import React from "react";
import { BrowserRouter as Router, Route, Routes, Link } from "react-router-dom"; // Impor Link dari react-router-dom
import "./App.css";
import Menu from "./components/Menu";
import About from "./components/About";
import OrderForm from "./components/OrderForm";
import Contact from "./components/Contact";
import Navbar from "./components/Navbar"; // Navbar sudah terpisah sebagai komponen

function App() {
  return (
    <Router>
      <div className="App">
        <header className="App-header">
          <h1>Restoran Fast Food</h1>
          <Navbar /> {/* Menambahkan Navbar sebagai komponen yang terpisah */}
          <nav>

          </nav>
        </header>
        <Routes>
          <Route path="/" element={<Menu />} />
          <Route path="/about" element={<About />} />
          <Route path="/order" element={<OrderForm />} />
          <Route path="/contact" element={<Contact />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
