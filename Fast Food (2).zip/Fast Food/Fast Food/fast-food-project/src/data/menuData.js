export const menuData = [
    {
      id: 1,
      name: "Burger Ayam",
      description: "Burger dengan ayam crispy dan saus spesial.",
      price: 25000,
      image: "/images/burger-ayam.jpg",
    },
    {
      id: 2,
      name: "Pommes Frites",
      description: "Kentang goreng renyah.",
      price: 15000,
      image: "/images/pommes-frites.jpg",
    },
    {
      id: 3,
      name: "Minuman Soda",
      description: "Minuman soda dingin yang menyegarkan.",
      price: 10000,
      image: "/images/minuman-soda.jpg",
    },
  ];