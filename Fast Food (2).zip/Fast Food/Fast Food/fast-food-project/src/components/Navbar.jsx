// src/components/Navbar.jsx
import React from 'react';
import { Link } from 'react-router-dom';

const Navbar = () => {
  return (
    <nav style={{
      backgroundColor: '#333', 
      padding: '10px 20px', 
      width: '100%',  // Membuat navbar memenuhi seluruh lebar layar
      display: 'flex', 
      justifyContent: 'space-between', 
      alignItems: 'center',
    }}>
      {/* Nama Brand / Logo */}
      <div style={{ color: '#fff', fontSize: '24px', fontWeight: 'bold' }}>
        Fast Food 
      </div>
      
      {/* Daftar Menu */}
      <ul style={{ listStyleType: 'none', display: 'flex', margin: 0, padding: 0 }}>
        <li style={{ marginRight: '20px' }}>
          <Link to="/" style={{ color: '#fff', textDecoration: 'none' }}>Home</Link>
        </li>
        <li style={{ marginRight: '20px' }}>
          <Link to="/about" style={{ color: '#fff', textDecoration: 'none' }}>About</Link>
        </li>
        <li style={{ marginRight: '20px' }}>
          <Link to="/order" style={{ color: '#fff', textDecoration: 'none' }}>Order</Link>
        </li>
        <li style={{ marginRight: '20px' }}>
          <Link to="/contact" style={{ color: '#fff', textDecoration: 'none' }}>Contact</Link>
        </li>
      </ul>
    </nav>
  );
};

export default Navbar;
