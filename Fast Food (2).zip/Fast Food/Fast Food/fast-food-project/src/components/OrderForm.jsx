import React, { useState } from "react";

const OrderForm = () => {
  const [name, setName] = useState("");
  const [foodItem, setFoodItem] = useState("");
  const [quantity, setQuantity] = useState(1);

  const handleSubmit = (e) => {
    e.preventDefault();
    alert(`Terima kasih, ${name}! Pesanan Anda: ${foodItem} x ${quantity}`);
  };

  return (
    <div className="order-form">
      <h2>Pemesanan Makanan</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>
            Nama:
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
            />
          </label>
        </div>
        <div>
          <label>
            Makanan:
            <select
              value={foodItem}
              onChange={(e) => setFoodItem(e.target.value)}
              required
            >
              <option value="">Pilih Makanan</option>
              <option value="Burger Ayam">Burger Ayam</option>
              <option value="Pommes Frites">Pommes Frites</option>
              <option value="Minuman Soda">Minuman Soda</option>
            </select>
          </label>
        </div>
        <div>
          <label>
            Jumlah:
            <input
              type="number"
              value={quantity}
              onChange={(e) => setQuantity(e.target.value)}
              min="1"
              required
            />
          </label>
        </div>
        <button type="submit">Pesan Sekarang</button>
      </form>
    </div>
  );
};

export default OrderForm;