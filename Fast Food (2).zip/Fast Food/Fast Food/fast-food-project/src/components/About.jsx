import React from "react";

const About = () => {
  return (
    <div className="about">
      <h2>Tentang Restoran Kami</h2>
      <p>
        Kami adalah restoran fast food yang menyediakan berbagai pilihan
        makanan cepat saji yang lezat dan terjangkau. Dengan bahan berkualitas
        dan layanan cepat, kami berkomitmen untuk memuaskan selera pelanggan
        kami.
      </p>
    </div>
  );
};

export default About;