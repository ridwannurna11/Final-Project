import React from 'react';
import { menuData } from '../data/menuData';

const Menu = () => {
  return (
    <div className="menu">
      <h2>Menu Restoran Fast Food</h2>
      <div className="menu-items">
        {menuData.map(item => (
          <div key={item.id} className="menu-item">
            <img src={item.image} alt={item.name} />
            <h3>{item.name}</h3>
            <p>{item.description}</p>
            <p><strong>Harga: Rp {item.price}</strong></p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Menu;