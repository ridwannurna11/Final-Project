import React from "react";

const Contact = () => {
  return (
    <div className="contact">
      <h2>Kontak Kami</h2>
      <p>Alamat: Jalan Fast Food No. 123, Jakarta, Indonesia</p>
      <p>Email: contact@fastfood.com</p>
      <p>Telepon: +62 812-3456-7890</p>
    </div>
  );
};

export default Contact;